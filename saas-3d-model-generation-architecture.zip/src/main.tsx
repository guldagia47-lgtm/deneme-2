import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { AuthProvider } from "@/auth/AuthProvider";
import { installMockGenerateModelEndpoint } from "@/lib/mockGenerateModelEndpoint";

installMockGenerateModelEndpoint();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>
  </StrictMode>
);
